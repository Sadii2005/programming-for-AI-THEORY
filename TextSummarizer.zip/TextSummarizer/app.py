from flask import Flask, render_template, request

#  SSL FIX (for NLTK download error)
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

# NLTK imports
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')   # ✅ ADD THIS LINE
nltk.download('stopwords')

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
import heapq

#  Initialize Flask app
app = Flask(__name__)

#  Text Summarization Function
def summarize(text):
    stopWords = set(stopwords.words("english"))
    words = word_tokenize(text)

    # Word frequency table
    freqTable = {}
    for word in words:
        word = word.lower()
        if word not in stopWords:
            freqTable[word] = freqTable.get(word, 0) + 1

    # Sentence tokenization
    sentences = sent_tokenize(text)

    sentenceValue = {}
    for sentence in sentences:
        for word in freqTable:
            if word in sentence.lower():
                sentenceValue[sentence] = sentenceValue.get(sentence, 0) + freqTable[word]

    # Average score
    if len(sentenceValue) == 0:
        return "No summary available."

    sumValues = sum(sentenceValue.values())
    avg = int(sumValues / len(sentenceValue))

    # Generate summary
    summary = ''
    for sentence in sentences:
        if sentence in sentenceValue and sentenceValue[sentence] > (1.2 * avg):
            summary += sentence + " "

    return summary


#  Flask Route
@app.route('/', methods=['GET', 'POST'])
def index():
    summary = ""
    if request.method == 'POST':
        text = request.form['text']
        summary = summarize(text)

    return render_template('index.html', summary=summary)


#  Run App
if __name__ == '__main__':
    app.run(debug=True)